# Exercise 9 Chapter 3 <br>
<h1>Author: Aida Matevosyan <br></h1>
<h1>R Markdown <br></h1>

<h2>9. This question involves the use of multiple linear regression on the Auto data set.</h2>


```R
auto = ISLR::Auto
```

# (a) Produce a scatterplot matrix which includes all of the variables in the data set.



```R
pairs(auto)
```


    
![png](output_3_0.png)
    


# (b) Compute the matrix of correlations between the variables using the function cor(). You will need to exclude the name variable, cor()which is qualitative.


```R
auto$name <- NULL
cor(auto,method = c("pearson"))
```


<table>
<thead><tr><th></th><th scope=col>mpg</th><th scope=col>cylinders</th><th scope=col>displacement</th><th scope=col>horsepower</th><th scope=col>weight</th><th scope=col>acceleration</th><th scope=col>year</th><th scope=col>origin</th></tr></thead>
<tbody>
	<tr><th scope=row>mpg</th><td> 1.0000000</td><td>-0.7776175</td><td>-0.8051269</td><td>-0.7784268</td><td>-0.8322442</td><td> 0.4233285</td><td> 0.5805410</td><td> 0.5652088</td></tr>
	<tr><th scope=row>cylinders</th><td>-0.7776175</td><td> 1.0000000</td><td> 0.9508233</td><td> 0.8429834</td><td> 0.8975273</td><td>-0.5046834</td><td>-0.3456474</td><td>-0.5689316</td></tr>
	<tr><th scope=row>displacement</th><td>-0.8051269</td><td> 0.9508233</td><td> 1.0000000</td><td> 0.8972570</td><td> 0.9329944</td><td>-0.5438005</td><td>-0.3698552</td><td>-0.6145351</td></tr>
	<tr><th scope=row>horsepower</th><td>-0.7784268</td><td> 0.8429834</td><td> 0.8972570</td><td> 1.0000000</td><td> 0.8645377</td><td>-0.6891955</td><td>-0.4163615</td><td>-0.4551715</td></tr>
	<tr><th scope=row>weight</th><td>-0.8322442</td><td> 0.8975273</td><td> 0.9329944</td><td> 0.8645377</td><td> 1.0000000</td><td>-0.4168392</td><td>-0.3091199</td><td>-0.5850054</td></tr>
	<tr><th scope=row>acceleration</th><td> 0.4233285</td><td>-0.5046834</td><td>-0.5438005</td><td>-0.6891955</td><td>-0.4168392</td><td> 1.0000000</td><td> 0.2903161</td><td> 0.2127458</td></tr>
	<tr><th scope=row>year</th><td> 0.5805410</td><td>-0.3456474</td><td>-0.3698552</td><td>-0.4163615</td><td>-0.3091199</td><td> 0.2903161</td><td> 1.0000000</td><td> 0.1815277</td></tr>
	<tr><th scope=row>origin</th><td> 0.5652088</td><td>-0.5689316</td><td>-0.6145351</td><td>-0.4551715</td><td>-0.5850054</td><td> 0.2127458</td><td> 0.1815277</td><td> 1.0000000</td></tr>
</tbody>
</table>



# (c) Use the lm() function to perform a multiple linear regression with mpg as the response and all other variables except name as the predictors. Use the summary() function to print the results.


```R
lm.fit<-lm(mpg~.,data=auto)
summary(lm.fit)
```


    
    Call:
    lm(formula = mpg ~ ., data = auto)
    
    Residuals:
        Min      1Q  Median      3Q     Max 
    -9.5903 -2.1565 -0.1169  1.8690 13.0604 
    
    Coefficients:
                   Estimate Std. Error t value Pr(>|t|)    
    (Intercept)  -17.218435   4.644294  -3.707  0.00024 ***
    cylinders     -0.493376   0.323282  -1.526  0.12780    
    displacement   0.019896   0.007515   2.647  0.00844 ** 
    horsepower    -0.016951   0.013787  -1.230  0.21963    
    weight        -0.006474   0.000652  -9.929  < 2e-16 ***
    acceleration   0.080576   0.098845   0.815  0.41548    
    year           0.750773   0.050973  14.729  < 2e-16 ***
    origin         1.426141   0.278136   5.127 4.67e-07 ***
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 3.328 on 384 degrees of freedom
    Multiple R-squared:  0.8215,	Adjusted R-squared:  0.8182 
    F-statistic: 252.4 on 7 and 384 DF,  p-value: < 2.2e-16
    


<h3>i. Is there a relationship between the predictors and the response?</h3><br>
Yes

<h3>ii.Which predictors appear to have a statistically significant relationship to the response?</h3><br>
origin, year, displacement, weight

<h3>iii.What does the coefficient for the year variable suggest?</h3><br>
The mpg value increase, whereas the other predictors are constant

<h3>iv. What does the coefficient for the year variable suggest?</h3><br>
The mpg value increase, whereas the other predictors are constant for each year

# (d) Use the plot() function to produce diagnostic plots of the linear regression fit. Comment on any problems you see with the fit.


```R
which.max(hatvalues(lm.fit))
```


<strong>14:</strong> 14



```R
par(mfrow = c(2,2))
plot(lm.fit)
```


    
![png](output_11_0.png)
    


# (e) Use the * and : symbols to fit linear regression models with interaction effects. Do any interactions appear to be statistically significant?


```R
summary(lm(formula = mpg ~ . * ., data = auto[, -9]))
```


    
    Call:
    lm(formula = mpg ~ . * ., data = auto[, -9])
    
    Residuals:
        Min      1Q  Median      3Q     Max 
    -7.6303 -1.4481  0.0596  1.2739 11.1386 
    
    Coefficients:
                                Estimate Std. Error t value Pr(>|t|)   
    (Intercept)                3.548e+01  5.314e+01   0.668  0.50475   
    cylinders                  6.989e+00  8.248e+00   0.847  0.39738   
    displacement              -4.785e-01  1.894e-01  -2.527  0.01192 * 
    horsepower                 5.034e-01  3.470e-01   1.451  0.14769   
    weight                     4.133e-03  1.759e-02   0.235  0.81442   
    acceleration              -5.859e+00  2.174e+00  -2.696  0.00735 **
    year                       6.974e-01  6.097e-01   1.144  0.25340   
    origin                    -2.090e+01  7.097e+00  -2.944  0.00345 **
    cylinders:displacement    -3.383e-03  6.455e-03  -0.524  0.60051   
    cylinders:horsepower       1.161e-02  2.420e-02   0.480  0.63157   
    cylinders:weight           3.575e-04  8.955e-04   0.399  0.69000   
    cylinders:acceleration     2.779e-01  1.664e-01   1.670  0.09584 . 
    cylinders:year            -1.741e-01  9.714e-02  -1.793  0.07389 . 
    cylinders:origin           4.022e-01  4.926e-01   0.816  0.41482   
    displacement:horsepower   -8.491e-05  2.885e-04  -0.294  0.76867   
    displacement:weight        2.472e-05  1.470e-05   1.682  0.09342 . 
    displacement:acceleration -3.479e-03  3.342e-03  -1.041  0.29853   
    displacement:year          5.934e-03  2.391e-03   2.482  0.01352 * 
    displacement:origin        2.398e-02  1.947e-02   1.232  0.21875   
    horsepower:weight         -1.968e-05  2.924e-05  -0.673  0.50124   
    horsepower:acceleration   -7.213e-03  3.719e-03  -1.939  0.05325 . 
    horsepower:year           -5.838e-03  3.938e-03  -1.482  0.13916   
    horsepower:origin          2.233e-03  2.930e-02   0.076  0.93931   
    weight:acceleration        2.346e-04  2.289e-04   1.025  0.30596   
    weight:year               -2.245e-04  2.127e-04  -1.056  0.29182   
    weight:origin             -5.789e-04  1.591e-03  -0.364  0.71623   
    acceleration:year          5.562e-02  2.558e-02   2.174  0.03033 * 
    acceleration:origin        4.583e-01  1.567e-01   2.926  0.00365 **
    year:origin                1.393e-01  7.399e-02   1.882  0.06062 . 
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 2.695 on 363 degrees of freedom
    Multiple R-squared:  0.8893,	Adjusted R-squared:  0.8808 
    F-statistic: 104.2 on 28 and 363 DF,  p-value: < 2.2e-16
    


We can see the significant terms (at the 0.05 level) are those with at least one asterisk (*)


```R

```
